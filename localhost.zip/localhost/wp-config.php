<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'wordpress' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '$N~uF$ s>xy[|Z(#VoCZ<xk0PGsh|J#yx9<ze.H+i_GmALNF1!@s0&yi&rA0Mlx>' );
define( 'SECURE_AUTH_KEY',  'vy[QO9sQI{#jXHv>lD1#;cS<6u(jw%h@!zev_N4m^iUAGvO[7m]Fbf/h!23RkSP#' );
define( 'LOGGED_IN_KEY',    '*4B@Lzs?@Km46CZFc+nu5aj+DruR{S-B5wV9>WyfvA$PT_~ZEFi#Q^Pk9mn438Jm' );
define( 'NONCE_KEY',        'J:8 =c3#[|qsvi2FG=hQi~{887!/2}~*MAEspxS@]/SN4-Bj( K$a n1aBp00/5U' );
define( 'AUTH_SALT',        ')3KlfX]8OfbwPUk3ARKXIOi$^$-6c=MAFSenznZC &+!*O/-XR>H6_jIbQIr 7=z' );
define( 'SECURE_AUTH_SALT', 'K(k {!H_qk 3F|:kWWGURw6eN+wW:3ne~<ej},0He,*VD?CjSEYKk3=^tD{%jm+`' );
define( 'LOGGED_IN_SALT',   'x!ZP~o~NmIr=Vy;06d/*(ZeBAqnM}F[/=hPW5:VdS2b0560z@p&<,f8}J@o=>#gi' );
define( 'NONCE_SALT',       'eQF!eiC>9a&^vLbEa0%8WucmDc/CTcMuRB)2j;,uCWXtJh&VODUy^w>qjiCZzwg)' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
